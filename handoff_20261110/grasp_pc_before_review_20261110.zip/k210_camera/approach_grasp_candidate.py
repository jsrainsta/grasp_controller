"""Commissioning hover and optional calibrated wrist roll, with no contact."""
import argparse
from datetime import datetime
import json
import math
from pathlib import Path
import time
import uuid
import cv2
import numpy as np
from check_grasp_board import ROOT
from collect_grasp_reference import read_arm
from fit_grasp_handeye import robot_frame,preview_wrist_alignment
from jpeg_integrity import check_jpeg
from plan_fixed_box_grasp import ik
from receive_photo import receive_photos
from sample_grasp_handeye import call,nominal_model
from track_box_reference import track
from grasp_start_state import WRIST_POSITION,require_start_state,start_state_error
from grasp_motion_profile import load_motion_profile
from tcp_pose_planner import plan_step
from wrist_roll import check_wrist_sweep,move_empty_wrist,roll_transform,wrist_target

def coarse_feedback(base):
    """One fresh joint read between already-confirmed coarse segments."""
    status=call(base,'status')
    if status.get('connection')!='connected' or status.get('active_task_id') is not None or status.get('upload_in_progress') or status.get('limits_require_recheck'):
        raise RuntimeError('预接近段间状态不允许继续')
    p=call(base,'positions?refresh=true')
    if p.get('fresh') is not True or p.get('source')!='serial':raise RuntimeError('预接近缺少新串口反馈')
    return {'status':{'ok':True,'mode':'serial','data':status},
            'joint_median':{str(v['id']):v['position'] for v in p['positions']}}

def path_margin(start,end,model,center,up,limits,tcp_offset=None,minimum_top_clearance=None):
    for j in ('3','4','5','6'):
        if not limits[int(j)][0]<=end[j]<=limits[int(j)][1]:
            raise ValueError('目标超出当前关节限位')
    gaps=[]
    for fraction in np.linspace(0,1,41):
        p={int(j):round(start[j]+(end[j]-start[j])*fraction) for j in start}
        # Feedback can be a few counts outside a commanded endpoint limit.
        # Accept only the existing small excursion while returning inside;
        # every new target above remains strictly inside configured limits.
        for j in ('3','4','5','6'):
            lo,hi=limits[int(j)]
            if not min(lo,start[j])<=p[int(j)]<=max(hi,start[j]) or not lo-10<=p[int(j)]<=hi+10:
                raise ValueError('路径超出关节反馈边界')
        pose=model.forward(p)
        point=np.array([pose['x_cm'],pose['y_cm'],pose['z_cm']])
        if tcp_offset is not None:
            point=robot_frame({str(j):v for j,v in p.items()},model,'pitch_tool')[:3,:3]@tcp_offset+point
        gap=float((point-center)@up)
        minimum=(2.8 if tcp_offset is not None else 4.7) if minimum_top_clearance is None else minimum_top_clearance
        if gap<minimum:
            raise ValueError('预接近路径名义余量不足')
        gaps.append(gap)
    return min(gaps)


def pregrasp_candidates(model,start,center,up,limits,tcp_offset,motion,height,rejections,*,split_descent=False):
    point=center+up*(height-2.5 if tcp_offset is not None else 5)
    candidates=[]
    pitches = (-90,-85,-80,-75,-70,-65,motion['preferred_nominal_pitch_deg'])
    if motion.get('adaptive_pitch_search'):
        low,high=motion['nominal_pitch_range_deg']
        pitches=(*pitches,low,high,*range(math.ceil(low),math.floor(high)+1))
    pitches=dict.fromkeys(pitches)
    for pitch in pitches:
        if not motion['nominal_pitch_range_deg'][0]<=pitch<=motion['nominal_pitch_range_deg'][1]:continue
        goal=point.copy()
        if tcp_offset is not None:
            yaw=math.atan2(point[1],point[0]);theta=math.radians(pitch)
            for iteration in range(5):
                c,s,ct,st=math.cos(yaw),math.sin(yaw),math.cos(theta),math.sin(theta)
                rotation=np.array([[c*ct,-s,-c*st],[s*ct,c,-s*st],[st,0,ct]])
                goal=point-rotation@tcp_offset
                yaw=math.atan2(goal[1],goal[0])
        for solution in ik(goal,pitch,model.to_config()):
            end={**start,**solution['illustrative_joint_positions_not_for_execution']}
            try:margin=path_margin(start,end,model,center,up,limits,tcp_offset,motion['pregrasp_min_top_clearance_cm'])
            except ValueError as error:
                reason=str(error)
                rejections[reason]=rejections.get(reason,0)+1
                continue
            joint_margin=min(min(end[j]-limits[int(j)][0],limits[int(j)][1]-end[j]) for j in ('3','4','5','6'))
            final_plan=None
            if motion.get('whole_path_precheck') and tcp_offset is not None:
                M=robot_frame(end,model,'pitch_tool');pre_tcp=M[:3,:3]@tcp_offset+M[:3,3]
                final=center+up*(motion['grasp_region']['tcp_height_target_cm']-2.5)
                try:
                    height_from_joints=float((pre_tcp-center)@up)+2.5
                    if split_descent:
                        # Check two shorter nominal steps, as the vision-guided
                        # approach can move in increments instead of one jump.
                        first=plan_step(model,end,(final-pre_tcp)*.5,pitch,tcp_offset,limits,
                            height_from_joints,up,motion['minimum_nominal_pad_height_cm'])
                        mid={**end,**first['expected_joint_positions']}
                        mid_tcp=pre_tcp+np.array(first['predicted_delta_cm'])
                        final_plan=plan_step(model,mid,final-mid_tcp,pitch,tcp_offset,limits,
                            float((mid_tcp-center)@up)+2.5,up,motion['minimum_nominal_pad_height_cm'])
                        joint_margin=min(joint_margin,first['joint_limit_margin'])
                    else:
                        final_plan=plan_step(model,end,final-pre_tcp,pitch,tcp_offset,limits,
                            height_from_joints,up,motion['minimum_nominal_pad_height_cm'])
                except ValueError:
                    reason='悬停到低位抓点的受限逆解不可用'
                    rejections[reason]=rejections.get(reason,0)+1
                    continue
                joint_margin=min(joint_margin,final_plan['joint_limit_margin'])
            candidates.append((5*max(0,20-joint_margin)+2*abs(pitch-motion['preferred_nominal_pitch_deg']),solution['rounding_error_cm'],end,margin))
    return point,candidates


def build_pregrasp_plan(model,start,center,up,limits,tcp_offset,motion):
    preferred=motion['pregrasp_height_cm']
    heights=[preferred]
    if tcp_offset is not None and motion.get('adaptive_pitch_search'):
        heights.extend(h for h in (preferred-.5,preferred+.5,preferred+1.)
                       if 4.2<=h<=8.5 and h-2.5>=motion['pregrasp_min_top_clearance_cm'])
    rejections={}
    split_descent=False
    for height in heights:
        point,candidates=pregrasp_candidates(model,start,center,up,limits,tcp_offset,motion,height,rejections)
        if candidates:break
    else:
        if tcp_offset is not None and motion.get('adaptive_pitch_search') and motion.get('whole_path_precheck'):
            # The safe and reachable band can lie between the coarse heights.
            ordered_heights=sorted(heights)
            midpoints=[(lo+hi)/2 for lo,hi in zip(ordered_heights,ordered_heights[1:])]
            split_heights=sorted(heights+midpoints,key=lambda height:(abs(height-preferred),height))
            for height in split_heights:
                point,candidates=pregrasp_candidates(model,start,center,up,limits,tcp_offset,motion,height,rejections,split_descent=True)
                if candidates:
                    split_descent=True
                    break
        if not candidates:
            reasons='、'.join(f'{reason}（{count}）' for reason,count in rejections.items())
            raise ValueError(f'悬停高度候选 {heights} cm 及适用的中间高度均无完整路径。{reasons or "悬停点没有可用逆解"}')
    _,_,end,margin=min(candidates,key=lambda row:row[:2])
    count=math.ceil(max(abs(end[j]-start[j]) for j in ('3','4','5','6'))/motion['maximum_coarse_joint_delta'])
    waypoints=[{j:round(start[j]+(end[j]-start[j])*i/count) for j in ('3','4','5','6')} for i in range(1,count+1)]
    return {'point':point,'end':end,'margin':margin,'waypoints':waypoints,
            'split_descent_precheck':split_descent,
            'height_above_support_cm':height if tcp_offset is not None else 7.5}


def plan_box_pregrasp(model,start,center,up,limits,tcp_offset,motion,length_axis):
    try:
        planned=build_pregrasp_plan(model,start,center,up,limits,tcp_offset,motion)
        return {**planned,'grasp_offset_base_cm':[0.,0.,0.]}
    except ValueError as center_error:
        along=motion['grasp_region']['along_length_cm']
        if tcp_offset is None or not motion.get('adaptive_pitch_search') or along<1.3:
            raise
        axis=np.array(length_axis,dtype=float)
        axis-=up*float(axis@up)
        axis/=np.linalg.norm(axis)
        # Move along the long edge, toward the arm, keeping the closing
        # direction centered across the box and room inside the grasp band.
        offset=-.8*axis if axis[:2]@center[:2]>0 else .8*axis
        try:
            planned=build_pregrasp_plan(model,start,center+offset,up,limits,tcp_offset,motion)
        except ValueError as offset_error:
            raise ValueError(f'盒心路径无解：{center_error}；盒内偏移抓点亦无解：{offset_error}') from offset_error
        return {**planned,'grasp_offset_base_cm':offset.tolist()}


def plan_hover_wrist(model,joints,center,up,width_axis,limits,tcp_offset,cal):
    frame=robot_frame(joints,model,'pitch_tool')
    tcp=frame[:3,:3]@tcp_offset+frame[:3,3]
    height=2.5+float((tcp-center)@up)
    target=wrist_target(cal,frame[:3,:3],width_axis,up)
    lo,hi=limits[2]
    check_wrist_sweep(target,joints,{'min':lo,'max':hi},height,up,model,tcp_offset,cal)
    return target,height


def plan_wrist_probe(model,joints,center,up,width_axis,limits,tcp_offset,cal):
    frame=robot_frame(joints,model,'pitch_tool')
    preview=preview_wrist_alignment(frame[:3,:3],width_axis,up)
    if preview['status']!='nominal_roll_preview':
        raise ValueError('无法从登记结果估计转腕方向')
    lo,hi=limits[2]
    low=max(lo,cal['position_range'][0])+3
    high=min(hi,cal['position_range'][1])-3
    if not low<=WRIST_POSITION<=high:
        raise ValueError('腕轴限位未覆盖试验中位')
    desired=round(WRIST_POSITION+preview['relative_roll_deg']/cal['degrees_per_count'])
    target=max(low,min(high,desired))
    # Bound displacement in any direction. The pivot used by this photo-only
    # trial deliberately leaves the TCP fixed in the nominal transform.
    sweep_deg=(abs(target-joints['2'])+5)*abs(cal['degrees_per_count'])
    displacement=4*math.sin(math.radians(sweep_deg)/2)
    tcp=frame[:3,:3]@tcp_offset+frame[:3,3]
    height=2.5+float((tcp-center)@up)-displacement
    check_wrist_sweep(target,joints,{'min':lo,'max':hi},height,up,model,tcp_offset,cal)
    return target,height


def main(argv=None, camera=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('observation',type=Path)
    parser.add_argument('--arm-url',default='http://127.0.0.1:18000/v1/arm')
    parser.add_argument('--port',default='COM5')
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--wrist-probe',action='store_true')
    parser.add_argument('--confirm-empty',action='store_true')
    parser.add_argument('--motion-profile',type=Path)
    parser.add_argument('--tcp-profile',type=Path,help='首次抓点候选，仅用于不接触的悬停验证')
    args=parser.parse_args(argv)
    motion=load_motion_profile(args.motion_profile)
    if args.wrist_probe:
        if args.execute and not args.confirm_empty:
            parser.error('实机转腕试验须现场确认空爪和完整留空')
        motion={**motion,'pregrasp_height_cm':max(motion['pregrasp_height_cm'],7.5),'whole_path_precheck':False}
    obs=json.loads(args.observation.read_text(encoding='utf-8'))
    geometry=obs['geometry'];target=geometry['selected']
    if target is None or not target['geometry_supported'] or obs['ocr']['target_selection']['status']!='target_found':
        raise ValueError('目标身份或几何不足')
    current=read_arm(args.arm_url);start=current['joint_median']
    if any(abs(start[j]-obs['after']['joint_median'][j])>8 for j in start):
        raise ValueError('当前姿态偏离定位图，需要重新观察')
    state=current['status']['data']
    if args.execute and state['capabilities'].get('writes_enabled') is not True:
        raise ValueError('运动未启用')
    limits={v['id']:(v['min'],v['max']) for v in state['servo_limits']}
    model=nominal_model();center=np.array(target['top_center_base_cm'])
    # Current 2.5cm box: first near TCP at 6cm above support, rather than
    # 6cm above its top (=8.5cm above support) followed by many tiny steps.
    up=-np.array(geometry['table_down_normal_base'])
    tcp_offset=None
    if args.tcp_profile:
        profile=json.loads(args.tcp_profile.read_text(encoding='utf-8'))
        if profile.get('allowed_stage')!='hover_only':raise ValueError('抓点配置不属于本阶段')
        require_start_state(start,profile['jaw_position'],profile['roll_position'],motion=motion)
        tcp_offset=np.array(profile['offset_tool_cm'],np.float64)
        if tcp_offset.shape!=(3,) or not np.isfinite(tcp_offset).all() or np.linalg.norm(tcp_offset)>4:
            raise ValueError('抓点候选无效')
    planned=plan_box_pregrasp(model,start,center,up,limits,tcp_offset,motion,target['length_axis_base'])
    point,end,margin,waypoints=(planned[k] for k in ('point','end','margin','waypoints'))
    count=len(waypoints)
    report={'type':'commissioning_pregrasp_clearance','source':str(args.observation.resolve()),
            'nominal_hover_cm':point.tolist(),'nominal_minimum_margin_cm':margin,
            'waypoints':waypoints,'commands':[],'completed':False,
            'physical_grasp_tcp_validated':False,'contact_motion_allowed':False}
    report['tcp_profile']=None if args.tcp_profile is None else str(args.tcp_profile.resolve())
    report['nominal_tcp_height_above_support_cm']=planned['height_above_support_cm']
    report['split_descent_precheck']=planned['split_descent_precheck']
    report['grasp_offset_base_cm']=planned['grasp_offset_base_cm']
    wrist_preview=preview_wrist_alignment(robot_frame(end,model,'pitch_tool')[:3,:3],target['width_axis_base'],up)
    report['wrist_alignment_preview']=wrist_preview
    wrist_roll=motion.get('wrist_roll')
    plan_wrist=plan_hover_wrist
    if args.wrist_probe:
        if tcp_offset is None:raise ValueError('悬停转腕需要抓点配置')
        # Existing empty-wrist samples: 458, 497, 536. This is a bounded
        # photo-only test, so never pass these estimates to the grasp observer.
        low_pitch,high_pitch=motion['nominal_pitch_range_deg']
        wrist_roll={'degrees_per_count':-.20,'position_range':[458,536],
                    'pivot_tool_cm':tcp_offset.tolist(),'minimum_sweep_tcp_height_cm':5.5,
                    'sweep_pitch_range_deg':[low_pitch-1.2,high_pitch+1.2],
                    'camera_rotates_with_wrist':False}
        plan_wrist=plan_wrist_probe
        report['wrist_probe']=True
    if wrist_roll:
        if tcp_offset is None:
            raise ValueError('悬停转腕需要抓点配置')
        sweep_cal={**wrist_roll,'minimum_sweep_tcp_height_cm':max(
            wrist_roll['minimum_sweep_tcp_height_cm'],2.5+motion['pregrasp_min_top_clearance_cm'])}
        roll_goal,_=plan_wrist(model,end,center,up,target['width_axis_base'],limits,tcp_offset,sweep_cal)
        if args.wrist_probe and abs(roll_goal-end['2'])<=2:
            raise ValueError('该摆位已接近腕轴目标，试验不会人为加转；请预览偏移摆位')
        if not args.wrist_probe:report['wrist_roll']=wrist_roll
        report['wrist_target_preview']=roll_goal
        print('预览2号舵机目标：',roll_goal,flush=True)
    report['motion_profile']=None if args.motion_profile is None else str(args.motion_profile.resolve())
    print('预接近方案：',waypoints,'模型最小余量cm：',round(margin,2),
          '悬停距支撑面cm：',planned['height_above_support_cm'],flush=True)
    if planned['split_descent_precheck']:
        print('低位抓点通过两段名义下降检查，实机仍按视觉反馈逐步接近。',flush=True)
    if any(planned['grasp_offset_base_cm']):
        print('采用盒内沿长边偏移 0.8 cm 的抓点。',flush=True)
    if not wrist_roll and wrist_preview['status']=='nominal_roll_preview':
        print('悬停腕轴预览：名义相对转角',round(wrist_preview['relative_roll_deg'],1),
              '度，尚无二号舵机标定。',flush=True)
    if not args.execute:return
    output=ROOT/'vision_grasp_results'/('hover_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]+'.json')
    def save():output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    try:
        for i,waypoint in enumerate(waypoints,1):
            before=current if i==1 else coarse_feedback(args.arm_url)
            if 'open_jaw_minimum' in motion and tcp_offset is not None:
                if i>1 and start_state_error(before['joint_median'],profile['jaw_position'],profile['roll_position'],motion=motion):
                    before=read_arm(args.arm_url)
                require_start_state(before['joint_median'],profile['jaw_position'],profile['roll_position'],motion=motion)
            elif any(abs(before['joint_median'][j]-start[j])>3 for j in ('1','2')):
                raise RuntimeError('夹爪或腕轴状态变化')
            limits={v['id']:(v['min'],v['max']) for v in before['status']['data']['servo_limits']}
            path_margin(before['joint_median'],{**before['joint_median'],**waypoint},model,center,up,limits,tcp_offset,motion['pregrasp_min_top_clearance_cm'])
            body={'request_id':'hover_'+uuid.uuid4().hex,'targets':[{'id':int(j),'position':v} for j,v in waypoint.items()],'duration_ms':20}
            command={'request':body,'response':None,'task':None};report['commands'].append(command);save()
            result=call(args.arm_url,'move',body);command['response']=result;save()
            task=result['task'];deadline=time.monotonic()+22
            while task['status']=='sent' and time.monotonic()<deadline:
                time.sleep(.3);task=call(args.arm_url,'tasks/'+task['task_id'])
            command['task']=task;save()
            if task['status']!='reached':raise RuntimeError('运动未确认：'+str(task))
            print('预接近',i,'/',count,'已到位',flush=True)
        time.sleep(.8)
        if wrist_roll:
            hover_state=read_arm(args.arm_url)
            joints=hover_state['joint_median']
            require_start_state(joints,profile['jaw_position'],profile['roll_position'],motion=motion)
            if any(abs(joints[j]-end[j])>10 for j in ('3','4','5','6')):
                raise RuntimeError('悬停反馈偏离规划终点，停止转腕')
            hover_limits={v['id']:(v['min'],v['max']) for v in hover_state['status']['data']['servo_limits']}
            roll_goal,height=plan_wrist(model,joints,center,up,target['width_axis_base'],
                                             hover_limits,tcp_offset,sweep_cal)
            report.update(wrist_target=roll_goal,wrist_start_tcp_height_cm=height)
            if abs(roll_goal-joints['2'])>2:
                open_target=motion.get('open_jaw_target') if args.wrist_probe else None
                move_empty_wrist(args.arm_url,roll_goal,hover_state,height,up,model,tcp_offset,sweep_cal,
                                 motion,read_arm,call,report.setdefault('wrist_commands',[]),save,
                                 open_target=open_target)
            elif args.wrist_probe:
                raise ValueError('该摆位已接近腕轴目标，试验不会人为加转；请预览偏移摆位')
            print('悬停转腕目标已核对，开始拍近照：',roll_goal,flush=True)
        captures=[]
        for attempt in range(2):
            before=read_arm(args.arm_url)
            if camera is None:
                image=receive_photos(args.port,115200,ROOT/'vision_grasp_images'/datetime.now().strftime('%Y%m%d'),once=True,request_capture=True)
            else:
                capture=camera.capture('hover_'+uuid.uuid4().hex)
                if capture['status']!='captured':raise RuntimeError('预接近拍照失败：'+str(capture))
                image=Path(capture['image_path'])
            if image is None:raise RuntimeError('未取得近图')
            after=read_arm(args.arm_url);integrity=check_jpeg(image)
            if wrist_roll:
                require_start_state(after['joint_median'],profile['jaw_position'],roll_goal,motion=motion)
            stable=(all(abs(before['joint_median'][j]-after['joint_median'][j])<=2 for j in before['joint_median'])
                    and all(v<=6 for reading in (before,after) for v in reading['joint_span'].values())
                    and all(v<=2 for reading in (before,after) for v in reading['joint_mad'].values()))
            captures.append({'image':str(image),'before':before,'after':after,'integrity':integrity,
                             'joint_feedback_stable':stable})
            report['captures']=captures;save()
            if integrity['valid'] and stable:break
            if attempt==0:
                print('近图校验或关节反馈未通过，原地等候后重拍一次。',flush=True)
                time.sleep(.8)
        else:raise RuntimeError('两次近图均未通过图像完整性和关节稳定检查')
        if args.wrist_probe:
            report.update(completed=True,hover_motion_completed=True,final=after)
            return
        reference=cv2.imdecode(np.frombuffer(Path(obs['image']).read_bytes(),np.uint8),0)
        frame=cv2.imdecode(np.frombuffer(Path(image).read_bytes(),np.uint8),0)
        cal=json.loads(Path(obs['calibration']).read_text(encoding='utf-8'))['candidates'][0]
        camera_mount=np.array(cal['T_mount_camera_cm'])
        if wrist_roll and wrist_roll['camera_rotates_with_wrist']:
            camera_mount=roll_transform(wrist_roll,after['joint_median']['2'])@camera_mount
        camera=robot_frame(after['joint_median'],model,'pitch_tool')@camera_mount
        inv=np.linalg.inv(camera)
        intrinsic=json.loads((ROOT/'camera_calibration_results'/'diagnostic_20261026_58dc9618'/'intrinsics_candidate.json').read_text(encoding='utf-8'))
        corners=np.array(target['top_corners_base_cm'])
        predicted=cv2.projectPoints(corners,cv2.Rodrigues(inv[:3,:3])[0],inv[:3,3],np.array(intrinsic['camera_matrix_px']),np.array(intrinsic['distortion_coefficients']))[0].reshape(-1,2)
        expected_scale=abs(cv2.contourArea(predicted.astype(np.float32)))/abs(cv2.contourArea(np.array(target['corners_pixel'],np.float32)))
        tracked=track(reference,frame,target['corners_pixel'],scale_bounds=(expected_scale*.6,expected_scale*1.6),coverage_basis='common_visible',current_face_hint=predicted)
        report.update(completed=True,hover_motion_completed=True,
                      near_tracking_accepted=tracked['status']=='tracked_face_for_review',
                      final=after,tracking=tracked,predicted_corners_pixel=predicted.tolist(),expected_scale=expected_scale)
        print('近端跟踪：',tracked,flush=True)
    except BaseException as error:
        report['error']=str(error);raise
    finally:save();print('预接近记录：',output,flush=True)


if __name__=='__main__':main()
